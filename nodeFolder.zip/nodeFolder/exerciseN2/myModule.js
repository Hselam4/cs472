/**
 * myDateModule.js
 */

myDate = function () {
    return Date();
};
exports.myDate = myDate;



 