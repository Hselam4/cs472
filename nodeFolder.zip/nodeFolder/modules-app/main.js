/**
 * main.js
 */
const hello = require("./helloModule");
hello("Selam");